"""shoppingmall URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url
from django.views.generic.base import TemplateView

# url pattern설정할때 사용할 수 있는 함수가
# url(), path(), re_path()
# url() : 원조. 정규표현식을 포함해서 일반적인 설정이 가능.
# url()이 불편해서 path()와 re_path()로 분리
# path()는 일반 문자열 형태로 url conf할 때
# re_path()는 정규표현식(regular expression)으로 url conf할 때
# 정규표현식 => [a-z]  => 영문자 소문자 1개 (b)
# 정규표현식 => [a-z]{3}  => 영문자 소문자 3개 (att)
# ^(Caret) : 문자열의 시작, $ : 문자열의 끝
# http://localhost:8000/
urlpatterns = [
    url(r'^$', TemplateView.as_view(template_name='index.html')),
    path('admin/', admin.site.urls),
    path('bbs/', include('bbs.urls'))
]
