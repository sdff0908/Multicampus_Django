
function new_post() {
    // bbs/create : 상대경로 => 현재경로를 기준으로 경로를 설정
    //                         http://localhost:8000/bbs/list
    location.href = '/bbs/create'
    // http://localhost:8000/bbs/list/bbs/create
    // /bbs/create : 절대경로 => http://localhost:8000 기준
    // http://localhost:8000/bbs/create
}