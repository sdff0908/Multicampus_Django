from django.shortcuts import render, redirect
from bbs.models import Post
from bbs.forms import PostForm


def p_list(request):
    # 데이터베이스의 모든 글의 내용을 다 들고와야 해요!
    posts = Post.objects.all().order_by('-id')
    return render(request, 'bbs/list.html',
                  {'posts': posts})


def p_create(request):

    # POST방식
    if request.method == 'POST':
        # 데이터베이스에 저장!!
        # 사용자가 전달해준 데이터는 request.POST 안에 들어있어요!
        post_form = PostForm(request.POST)

        if post_form.is_valid():
            post_form.save()
            return redirect('bbs:p_list')

    # GET방식
    if request.method == 'GET':
        # 빈입력 form을 출력하는 코드가 나오면 되요!
        post_form = PostForm()
        return render(request, 'bbs/create.html',
                      {'post_form': post_form})
