from django.contrib import admin
from bbs.models import Post

admin.site.register(Post)
