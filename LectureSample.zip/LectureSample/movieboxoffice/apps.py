from django.apps import AppConfig


class MovieboxofficeConfig(AppConfig):
    name = 'movieboxoffice'
