
function new_post() {
    $(location).attr('href','/bbs/create');
}