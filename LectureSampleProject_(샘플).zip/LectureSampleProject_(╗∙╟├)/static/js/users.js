
$(function() {
    $('#signupBtn').on('click',function() {
        $(location).attr('href','/users/signup');
    })
})